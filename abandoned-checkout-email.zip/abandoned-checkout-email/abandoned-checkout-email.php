<?php
/*
Plugin Name: Abandoned Checkout Email
Description: Sends an email with the details of an abandoned checkout.
Version: 1.0
Author: Abdul Moid
*/

// Register AJAX actions for logged-in and non-logged-in users
add_action('wp_ajax_send_email', 'callback_send_email');
add_action('wp_ajax_nopriv_send_email', 'callback_send_email');

// Function to handle the AJAX request and send email
function callback_send_email() {
    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $phone = sanitize_text_field($_POST['phone']);
    $city = sanitize_text_field($_POST['city']);
    $address1 = sanitize_text_field($_POST['address1']);
    $address2 = sanitize_text_field($_POST['address2']);
    $grandtotal = sanitize_text_field($_POST['grandtotal']);
    $productDetailsJSON = $_POST['productDetails'];
    $productDetails = json_decode($productDetailsJSON, true);
    $formattedProductDetails = '';

    if (!empty($productDetails)) {
        foreach ($productDetails as $product) {
            $formattedProductDetails .= "<b>Product Name:</b> " . $product['name'] . "<br>"
                                      . "<b>Total:</b> " . $product['total'] . "<br><br>";
        }
    }

    $cart_items = WC()->cart->get_cart();
    foreach ($cart_items as $cart_item_key => $cart_item) {
        $product = $cart_item['data'];
        $formattedProductDetails .= "<b>Product Name:</b> " . $product->get_name() . "<br>"
                                  . "<b>Quantity:</b> " . $cart_item['quantity'] . "<br>"
                                  . "<b>Price:</b> " . wc_price($product->get_price()) . "<br>"
                                  . "<b>Total:</b> " . wc_price($cart_item['line_total']) . "<br><br>";
    }

    $recipient_email = get_option('abandoned_checkout_email_recipient', 'info@mbcollections.com.pk');
    $sender_email = get_option('abandoned_checkout_email_sender', 'no-reply@yourdomain.com');
    $subject = "Abandoned Checkout Details";
    $to = $recipient_email;
    $message = "<b>Name: </b> " . $name . "<br>" .
               "<b>Email: </b>" . $email . "<br>" .
               "<b>Phone: </b>" . $phone . "<br>" .
               "<b>City: </b>" . $city . "<br>" .
               "<b>Address1: </b>" . $address1 . "<br>" .
               "<b>Address2: </b>" . $address2 . "<br>" .
               "<h2>Product Details</h2>" . $formattedProductDetails .
               "<h2>Grand Total</h2>" .
               "<b>Grand Total: </b>" . $grandtotal . "<br>";

    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: " . $sender_email . "\r\n";
    $headers .= "Reply-To: $email \r\n";

    $retval = wp_mail($to, $subject, $message, $headers);

    if ($retval) {
        echo "Message sent successfully...";
    } else {
        echo "Message could not be sent...";
    }

    wp_die();
}

// Enqueue custom script on checkout page
add_action('wp_enqueue_scripts', 'enqueue_custom_script');
function enqueue_custom_script() {
    if (is_checkout()) {
        wp_enqueue_script('custom-checkout-script', plugin_dir_url(__FILE__) . 'custom-checkout-script.js', array('jquery'), null, true);
        wp_localize_script('custom-checkout-script', 'checkout_params', array(
            'ajax_url' => admin_url('admin-ajax.php')
        ));
    }
}

// Add settings page
add_action('admin_menu', 'abandoned_checkout_email_menu');
function abandoned_checkout_email_menu() {
    add_options_page('Abandoned Checkout Email Settings', 'Abandoned Checkout Email', 'manage_options', 'abandoned-checkout-email', 'abandoned_checkout_email_options');
}

// Display settings page
function abandoned_checkout_email_options() {
    ?>
    <div class="wrap">
        <h1>Abandoned Checkout Email Settings</h1>
        <form method="post" action="options.php">
            <?php settings_fields('abandoned_checkout_email_options_group'); ?>
            <?php do_settings_sections('abandoned_checkout_email_options_group'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Recipient Email</th>
                    <td><input type="email" name="abandoned_checkout_email_recipient" value="<?php echo esc_attr(get_option('abandoned_checkout_email_recipient')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Sender Email</th>
                    <td><input type="email" name="abandoned_checkout_email_sender" value="<?php echo esc_attr(get_option('abandoned_checkout_email_sender')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Register and define the settings
add_action('admin_init', 'abandoned_checkout_email_settings');
function abandoned_checkout_email_settings() {
    register_setting('abandoned_checkout_email_options_group', 'abandoned_checkout_email_recipient');
    register_setting('abandoned_checkout_email_options_group', 'abandoned_checkout_email_sender');
}
?>
