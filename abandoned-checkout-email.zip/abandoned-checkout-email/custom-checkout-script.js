jQuery(document).ready(function($) {
    $('#billing_phone').on('change', function() {
        var phone = $(this).val();
        if (phone) {
            var productDetails = [];
            $('.woocommerce-checkout-review-order-table .cart_item').each(function() {
                var productName = $(this).find('.product-name').text().trim();
                var productTotal = $(this).find('.product-total .woocommerce-Price-amount').text().trim();
                productDetails.push({name: productName, total: productTotal});
            });

            var productDetailsString = JSON.stringify(productDetails);

            $.ajax({
                url: checkout_params.ajax_url,
                type: 'post',
                data: {
                    action: 'send_email',
                    name: $('#billing_first_name').val() + ' ' + $('#billing_last_name').val(),
                    email: $('#billing_email').val(),
                    phone: phone,
                    city: $('#billing_city').val(),
                    address1: $('#billing_address_1').val(),
                    address2: $('#billing_address_2').val(),
                    grandtotal: $('#order_review .order-total .amount').text(),
                    productDetails: productDetailsString
                },
                success: function(response) {
                    console.log('Email sent successfully: ' + response);
                },
                error: function(error) {
                    console.log('Error in sending email: ' + error);
                }
            });
        }
    });
});
